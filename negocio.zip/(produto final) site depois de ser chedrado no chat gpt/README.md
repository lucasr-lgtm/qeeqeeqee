# Frutaria — projeto HTML, CSS e JavaScript

Site educativo com **15 páginas HTML únicas**, inspirado nos arquivos enviados e no tema frutas.

## Como executar

1. Extraia o arquivo ZIP.
2. Abra a pasta `frutaria_site` no Visual Studio Code (ou outro editor).
3. Inicie um servidor local, por exemplo pela extensão **Live Server** do VS Code. Alternativamente, no terminal, dentro da pasta do projeto, execute `python -m http.server 5500`.
4. Acesse `http://localhost:5500` e abra `index.html`.

O site também pode ser aberto diretamente em muitos navegadores, mas um servidor local é recomendado para testar as integrações externas com `fetch()`.

## Requisitos do trabalho

- **15 páginas únicas:** `index.html`, 13 páginas de frutas e `sobre.html`.
- **Três níveis de CSS:** arquivo externo `assets/css/style.css`; bloco `<style>` interno em cada página; estilos inline em elementos pontuais.
- **Seletores CSS:** seletores por tag (`body`, `h1`, `p`, `button`), por classe (`.fruit-card`, `.page-hero`, `.info-card`) e por ID (`#main-content`, `#toast`, `#fruit-search`).
- **JavaScript em todas as páginas:** filtro no catálogo, interações específicas de frutas, favoritos locais e formulário demonstrativo.
- **Três APIs, em três páginas diferentes:**
  - `maca.html` — Open Food Facts: pesquisa produtos e exibe valores nutricionais disponíveis no cadastro.
  - `abacaxi.html` — TheMealDB: busca receitas pelo ingrediente e carrega instruções.
  - `abobora.html` — Open-Meteo: localiza a cidade e apresenta condições atuais e previsão de cinco dias.

## Organização

```text
frutaria_site/
├── index.html
├── tomate.html ... ameixa.html
├── sobre.html
└── assets/
    ├── css/style.css
    └── js/
        ├── main.js
        ├── api-openfoodfacts.js
        ├── api-themealdb.js
        └── api-openmeteo.js
```

## Observações sobre as APIs

As três integrações dependem de conexão com a internet e dos serviços externos estarem disponíveis. As páginas mostram uma mensagem de erro quando uma consulta falha.

- [Open Food Facts](https://world.openfoodfacts.org/) — base colaborativa de produtos. A busca usa o endpoint público de pesquisa; produtos e campos nutricionais podem variar conforme os registros disponíveis.
- [TheMealDB](https://www.themealdb.com/api.php) — API de receitas; o projeto utiliza a chave pública de teste `1`, adequada para aprendizagem e desenvolvimento.
- [Open-Meteo](https://open-meteo.com/) — geocodificação e previsão meteorológica; não exige chave para o uso não comercial previsto pela documentação do serviço. A atribuição é indicada na página.

## Recursos JavaScript demonstrados

Filtro instantâneo no catálogo, salvamento de favoritos em `localStorage`, botões que revelam conteúdo, calculadora ilustrativa, quiz, montagem de combinação de vitamina, cópia de dica, alternância de tamanho de texto, busca de receitas, busca de produtos e previsão do tempo.

> Os dados apresentados são informativos e demonstrativos. Informações de produtos são fornecidas pelos usuários da base colaborativa, e dados meteorológicos não substituem orientação agrícola local.
