(() => {
  const form = document.getElementById('off-form');
  if (!form) return;
  const status = document.getElementById('off-status');
  const results = document.getElementById('off-results');
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const term = document.getElementById('off-query').value.trim();
    if (!term) return;
    status.textContent = 'Consultando o catálogo de produtos…'; status.classList.add('loading'); results.innerHTML = '';
    try {
      const params = new URLSearchParams({search_terms:term,search_simple:'1',action:'process',json:'1',page_size:'6',fields:'product_name,brands,image_url,quantity,nutriments,nutrition_grades'});
      const response = await fetch(`https://world.openfoodfacts.org/cgi/search.pl?${params.toString()}`, {headers:{'Accept':'application/json'}});
      if (!response.ok) throw new Error(`A API respondeu com status ${response.status}.`);
      const data = await response.json();
      const products = (data.products || []).filter((item) => item.product_name);
      if (!products.length) { status.textContent = 'Nenhum produto encontrado. Tente outro termo, como “apple juice” ou “suco de maçã”.'; return; }
      status.textContent = `${products.length} produto(s) encontrado(s). Os dados dependem do cadastro de cada item.`;
      results.innerHTML = products.map((product) => {
        const n = product.nutriments || {};
        const kcal = n['energy-kcal_100g'] ?? n['energy-kcal_value'] ?? '—';
        const sugars = n.sugars_100g ?? '—';
        const fiber = n.fiber_100g ?? '—';
        const brand = product.brands ? ` · ${esc(product.brands)}` : '';
        const image = product.image_url ? `<img src="${esc(product.image_url)}" alt="" loading="lazy">` : '<div class="product-placeholder">🍎</div>';
        return `<article class="product-result">${image}<div><h3>${esc(product.product_name)}</h3><p>${brand || 'Marca não informada'}${product.quantity ? ` · ${esc(product.quantity)}` : ''}</p><div class="nutri-tags"><span>${esc(kcal)} kcal/100g</span><span>Açúcares: ${esc(sugars)} g</span><span>Fibras: ${esc(fiber)} g</span></div></div></article>`;
      }).join('');
    } catch (error) {
      status.textContent = `Não foi possível consultar a API agora. Verifique sua conexão e tente novamente. Detalhe: ${error.message}`;
    } finally { status.classList.remove('loading'); }
  });
})();
