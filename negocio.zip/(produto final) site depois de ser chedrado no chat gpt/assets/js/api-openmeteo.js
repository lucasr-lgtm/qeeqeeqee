(() => {
  const form = document.getElementById('weather-form');
  if (!form) return;
  const status = document.getElementById('weather-status');
  const results = document.getElementById('weather-results');
  const weatherLabel = (code) => {
    if (code === 0) return 'Céu limpo';
    if ([1,2,3].includes(code)) return 'Parcialmente nublado';
    if ([45,48].includes(code)) return 'Neblina';
    if ([51,53,55,56,57].includes(code)) return 'Garoa';
    if ([61,63,65,66,67,80,81,82].includes(code)) return 'Chuva';
    if ([71,73,75,77,85,86].includes(code)) return 'Neve';
    if ([95,96,99].includes(code)) return 'Trovoadas';
    return 'Condição variável';
  };
  const dayLabel = (iso) => new Intl.DateTimeFormat('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit'}).format(new Date(`${iso}T12:00:00`));
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const city = document.getElementById('weather-city').value.trim();
    if (!city) return;
    status.textContent = 'Localizando a cidade e consultando a previsão…'; status.classList.add('loading'); results.innerHTML = '';
    try {
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?${new URLSearchParams({name:city,count:'1',language:'pt',format:'json'})}`;
      const geoResponse = await fetch(geoUrl);
      if (!geoResponse.ok) throw new Error('Falha ao localizar a cidade.');
      const geo = await geoResponse.json();
      const place = geo.results?.[0];
      if (!place) { status.textContent = 'Cidade não encontrada. Confira a escrita e tente novamente.'; return; }
      const params = new URLSearchParams({latitude:place.latitude,longitude:place.longitude,current:'temperature_2m,relative_humidity_2m,precipitation,weather_code',daily:'temperature_2m_max,temperature_2m_min,precipitation_sum',timezone:'auto',forecast_days:'5'});
      const forecastResponse = await fetch(`https://api.open-meteo.com/v1/forecast?${params}`);
      if (!forecastResponse.ok) throw new Error('Falha ao carregar a previsão meteorológica.');
      const forecast = await forecastResponse.json();
      const current = forecast.current;
      const days = forecast.daily.time.map((date,index) => `<article class="weather-day"><strong>${dayLabel(date)}</strong><span>${Math.round(forecast.daily.temperature_2m_max[index])}° / ${Math.round(forecast.daily.temperature_2m_min[index])}°</span><small>Chuva: ${forecast.daily.precipitation_sum[index]} mm</small></article>`).join('');
      status.textContent = `Previsão para ${place.name}${place.admin1 ? `, ${place.admin1}` : ''}${place.country ? ` — ${place.country}` : ''}.`;
      results.innerHTML = `<div class="weather-current"><span aria-hidden="true">🌤️</span><div><strong>${Math.round(current.temperature_2m)}°C</strong><p>${weatherLabel(current.weather_code)} · Umidade ${current.relative_humidity_2m}% · Precipitação ${current.precipitation} mm</p></div></div><div class="weather-days">${days}</div>`;
    } catch (error) { status.textContent = `Não foi possível consultar a previsão agora. Verifique sua conexão e tente novamente. Detalhe: ${error.message}`; }
    finally { status.classList.remove('loading'); }
  });
})();
