(() => {
  const form = document.getElementById('meal-form');
  if (!form) return;
  const status = document.getElementById('meal-status');
  const results = document.getElementById('meal-results');
  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const ingredient = document.getElementById('meal-ingredient').value;
    status.textContent = 'Buscando receitas no TheMealDB…'; status.classList.add('loading'); results.innerHTML = '';
    try {
      const response = await fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(ingredient)}`);
      if (!response.ok) throw new Error(`A API respondeu com status ${response.status}.`);
      const data = await response.json();
      const meals = (data.meals || []).slice(0, 9);
      if (!meals.length) { status.textContent = 'Não foram encontradas receitas para esse ingrediente no catálogo.'; return; }
      status.textContent = `${meals.length} receita(s) exibida(s). Abra os detalhes para consultar as instruções.`;
      results.innerHTML = meals.map((meal) => `<article class="recipe-card"><img src="${esc(meal.strMealThumb)}" alt="Foto de ${esc(meal.strMeal)}" loading="lazy"><div><h3>${esc(meal.strMeal)}</h3><button type="button" data-meal-id="${esc(meal.idMeal)}">Ver instruções</button></div></article>`).join('');
      results.querySelectorAll('[data-meal-id]').forEach((button) => button.addEventListener('click', async () => {
        const id = button.dataset.mealId;
        button.disabled = true; button.textContent = 'Carregando…';
        try {
          const detailResponse = await fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${encodeURIComponent(id)}`);
          if (!detailResponse.ok) throw new Error('Não foi possível carregar os detalhes.');
          const detailData = await detailResponse.json();
          const meal = detailData.meals?.[0];
          if (!meal) throw new Error('Receita não encontrada.');
          const old = results.querySelector('.recipe-detail'); if (old) old.remove();
          const detail = document.createElement('div'); detail.className = 'recipe-detail';
          const instructions = (meal.strInstructions || 'Instruções não informadas.').slice(0, 1400);
          detail.innerHTML = `<strong>${esc(meal.strMeal)}</strong><p>${esc(instructions)}${meal.strInstructions?.length > 1400 ? '…' : ''}</p>`;
          results.appendChild(detail);
          detail.scrollIntoView({behavior:'smooth',block:'nearest'});
        } catch (error) { status.textContent = error.message; }
        finally { button.disabled = false; button.textContent = 'Ver instruções'; }
      }));
    } catch (error) { status.textContent = `Não foi possível consultar a API agora. Verifique sua conexão e tente novamente. Detalhe: ${error.message}`; }
    finally { status.classList.remove('loading'); }
  });
})();
