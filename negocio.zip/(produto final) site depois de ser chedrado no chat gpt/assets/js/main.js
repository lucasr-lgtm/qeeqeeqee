(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const toast = (message) => {
    const node = $('#toast');
    if (!node) return;
    node.textContent = message;
    node.classList.add('show');
    clearTimeout(window.__frutariaToastTimer);
    window.__frutariaToastTimer = setTimeout(() => node.classList.remove('show'), 2600);
  };
  const safeStorage = {
    get(key) { try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch { return []; } },
    set(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* armazenamento indisponível */ } }
  };

  // Ação global: salvar ou remover a página dos favoritos locais.
  $$('[data-action="favorite"]').forEach((button) => {
    const slug = location.pathname.split('/').pop() || 'index.html';
    const favorites = safeStorage.get('frutaria-favorites');
    const active = favorites.includes(slug);
    button.setAttribute('aria-pressed', String(active));
    button.querySelector('span').textContent = active ? '♥' : '♡';
    button.addEventListener('click', () => {
      const current = safeStorage.get('frutaria-favorites');
      const exists = current.includes(slug);
      const next = exists ? current.filter((item) => item !== slug) : [...current, slug];
      safeStorage.set('frutaria-favorites', next);
      button.setAttribute('aria-pressed', String(!exists));
      button.querySelector('span').textContent = exists ? '♡' : '♥';
      toast(exists ? 'Leitura removida dos favoritos.' : 'Página salva nos favoritos deste navegador.');
    });
  });

  // Página inicial: filtro instantâneo do catálogo.
  const search = $('#fruit-search');
  if (search) {
    const cards = $$('.fruit-card');
    const count = $('#fruit-count');
    const empty = $('#empty-search');
    search.addEventListener('input', () => {
      const term = search.value.trim().toLocaleLowerCase('pt-BR');
      let visible = 0;
      cards.forEach((card) => {
        const match = card.dataset.search.includes(term);
        card.hidden = !match;
        if (match) visible++;
      });
      count.textContent = `${visible} ${visible === 1 ? 'fruta' : 'frutas'}`;
      empty.hidden = visible !== 0;
    });
  }

  // Interações específicas das páginas informativas.
  $$('[data-page-action]').forEach((button) => button.addEventListener('click', () => {
    const action = button.dataset.pageAction;
    if (action === 'tomato-extra' || action === 'mango-show' || action === 'pineapple-hint') {
      const target = document.getElementById(button.getAttribute('aria-controls'));
      if (!target) return;
      const show = target.hidden;
      target.hidden = !show;
      button.setAttribute('aria-expanded', String(show));
      button.textContent = show ? 'Ocultar curiosidade' : (action === 'tomato-extra' ? 'Mostrar mais uma curiosidade' : action === 'mango-show' ? 'Ver combinação de sabores' : 'Mostrar dica de preparo');
    }
    if (action === 'banana-ripen') {
      const stages = [
        {emoji:'🟢',name:'Verde',note:'Mais firme e com sabor menos doce.'},
        {emoji:'🍌',name:'Amarela',note:'Mais macia e com sabor adocicado.'},
        {emoji:'🍌',name:'Amarela com pintas',note:'Bem madura; ótima para bolos e vitaminas.'}
      ];
      const node = $('#banana-stage');
      const current = Number(button.dataset.stage || 0);
      const next = (current + 1) % stages.length;
      button.dataset.stage = String(next);
      $('#banana-stage-emoji').textContent = stages[next].emoji;
      node.textContent = stages[next].name;
      $('#banana-stage-note').textContent = stages[next].note;
    }
    if (action === 'watermelon-cut') $('#watermelon-art').classList.toggle('slice-mode');
    if (action === 'orange-calc') {
      const amount = Math.max(1, Math.min(30, Number($('#orange-count').value) || 1));
      const cups = (amount / 3).toFixed(1).replace('.', ',');
      $('#orange-result').textContent = `Estimativa ilustrativa: ${amount} laranjas podem render cerca de ${cups} copo(s), considerando aproximadamente 3 frutas por copo. O rendimento real varia.`;
    }
    if (action === 'pear-quiz') {
      const answer = $('#pear-answer').value;
      $('#pear-result').textContent = answer === 'a' ? 'Isso mesmo! A pera pode ser assada, cozida e também consumida fresca.' : answer ? 'Não é essa. A pera pode ser consumida fresca, assada ou cozida.' : 'Escolha uma opção antes de conferir.';
    }
    if (action === 'papaya-recipe') {
      const chosen = $$('input[name="papaya-ing"]:checked').map((item) => item.value);
      $('#papaya-result').textContent = chosen.length ? `Sua combinação: ${chosen.join(' + ')}. Bata os ingredientes com um pouco de água ou leite e ajuste a textura como preferir.` : 'Marque ao menos um ingrediente para montar sua combinação.';
    }
    if (action === 'plum-copy') {
      const text = $('#plum-tip').textContent;
      if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(() => toast('Dica copiada!')).catch(() => toast('Não foi possível copiar neste navegador.'));
      else toast('Selecione a dica e copie manualmente.');
    }
    if (action === 'peach-read') {
      document.body.classList.toggle('font-large');
      button.textContent = document.body.classList.contains('font-large') ? 'Voltar ao tamanho normal' : 'Aumentar o texto';
    }
  }));

  // Uvas: alternância entre formas de consumo.
  $$('[data-grape]').forEach((button) => button.addEventListener('click', () => {
    $$('[data-grape]').forEach((item) => item.classList.toggle('is-active', item === button));
    $('#grape-mode').textContent = button.dataset.grape === 'fresh'
      ? 'Uvas frescas: lave em água corrente e sirva geladas, em saladas ou como lanche.'
      : 'Uvas congeladas: seque bem, distribua em uma bandeja e congele antes de guardar em um recipiente.';
  }));

  // Sobre: formulário demonstrativo, sem envio ou armazenamento de dados pessoais.
  const feedback = $('#feedback-form');
  if (feedback) feedback.addEventListener('submit', (event) => {
    event.preventDefault();
    const value = $('#feedback-choice').value;
    $('#feedback-result').textContent = value ? `Obrigado pela avaliação: “${value}”. Ela foi registrada apenas nesta demonstração.` : 'Selecione uma avaliação antes de enviar.';
  });
})();
